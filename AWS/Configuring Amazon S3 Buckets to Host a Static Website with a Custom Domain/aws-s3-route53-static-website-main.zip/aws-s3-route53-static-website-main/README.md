# aws-s3-route53-static-website
HoL Repository for "Configuring Amazon S3 Buckets to Host a Static Website with a Custom Domain"
